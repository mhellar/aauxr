# curve

curve.

Built with [A-Frame](https://aframe.io).

## Setup

```sh
npm install
npm run start
```

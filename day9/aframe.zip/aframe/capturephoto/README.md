# 8th Wall Web Examples - AFrame - Capture photo

This example allows the user to capture photo evidence of a UFO abduction. This showcases the 8th Wall Web screenshot API as well as using HTML to show an interface controlled by an A-Frame component.

![capture-screenshot](../../../images/screenshot-capture.jpg)

[Try the live demo here](https://templates.8thwall.app/capturephoto-aframe)
